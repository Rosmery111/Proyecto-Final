<?php
 define('DB_HOST','localhost');
 define('DB_USER','root');
 define('DB_PASS','');
 define('DB_NAME','prueba');
class connection{
    
        static $o_connection = null;
    
        static function obj(){
            if(self::$o_connection == null){
                self::$o_connection = new connection();
            }
            return self::$o_connection->instancia;
        } 
        
        public $instancia = null;
        
            function __construct(){
                $this->instancia = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
    
                if($this->instancia == false){
                    echo "<script>
                        window.location = './install.php';
                    </script>";   
                    exit();
                }
            }
        
            function __destruct(){
                mysqli_close($this->instancia);
            }
        }
$msj="";
$host = "";
$user = "";
$pass = "";
$name = "";

if($_POST){
    $host = $_POST['host'];
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    $name = $_POST['name'];
    
    $con = true;

    if($con){
        $connection = mysqli_connect($host,$user,$pass);
      

            $query="CREATE DATABASE {$name}";
            mysqli_query($connection, $query);

            mysqli_query($connection, "use {$name}");

            $query="DROP TABLE IF EXISTS `form`;";
            mysqli_query($connection, $query);

            $query="CREATE TABLE `galeria` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `nombre` int(11) NOT NULL,
                `descripcion` varchar(50) DEFAULT NULL,
                PRIMARY KEY (`id`)
              ) ENGINE=MyISAM 
               DEFAULT CHARSET=utf8;";
            mysqli_query($connection, $query);

            $query="DROP TABLE IF EXISTS `usuarios`;";
            mysqli_query($connection, $query);

            $query="CREATE TABLE `usuarios` (
                `cedula` int(11) NOT NULL,
                `nombre` varchar(50) NOT NULL,
                `apellido` varchar(50) NOT NULL,
                `telefono` varchar(50),
                `correo` varchar(18) NOT NULL,
                `celular` varchar(18) NOT NULL,
                `direccion` varchar(18) NOT NULL,
                `latitud` varchar(18) NOT NULL,
                `longitud` varchar(18) NOT NULL,
                `foto` varchar(18) NOT NULL,
                PRIMARY KEY (`cedula`)
              ) ENGINE=MyISAM 
               DEFAULT CHARSET=utf8;";
            mysqli_query($connection, $query);

            $query="DROP TABLE IF EXISTS `login`;";
            mysqli_query($connection, $query);

            $query="CREATE TABLE `login` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `cedula` varchar NOT NULL,
                `email` varchar(50),
                `pass` varchar(18) NOT NULL,
                PRIMARY KEY (`id`)
              ) ENGINE=MyISAM 
               DEFAULT CHARSET=utf8;";
            mysqli_query($connection, $query); 

            $query = "ALTER TABLE `registro` ADD UNIQUE(`usuario`);";
            mysqli_query($connection, $query);
            
    }
    $active_group= '$active_group';
    $query_builder='$query_builder';
    $db='$db';
    $info="
    <?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    {$active_group} = 'default';
    {$query_builder} = TRUE;
    
    {$db}['default'] = array(
        'dsn'	=> '',
        'hostname' => '{$host}',
        'username' => '{$user}',
        'password' => '{$pass}',
        'database' => '{$name}',
        'dbdriver' => 'mysqli',
        'dbprefix' => '',
        'pconnect' => FALSE,
        'db_debug' => (ENVIRONMENT !== 'production'),
        'cache_on' => FALSE,
        'cachedir' => '',
        'char_set' => 'utf8',
        'dbcollat' => 'utf8_general_ci',
        'swap_pre' => '',
        'encrypt' => FALSE,
        'compress' => FALSE,
        'stricton' => FALSE,
        'failover' => array(),
        'save_queries' => TRUE
    );
    ";

    file_put_contents("application/config/database.php", $info);

    echo"
    <script>
    alert('Base de Datos Instalada');
    window.location = 'index.php/';
    </script>
    ";

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Install DataBase</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <style>
        .error{
            color:red;
            font-weight:bold;
            font-size:25px;
        }
        body{background-image: url("img/background.jpg");}
  
    </style>
</head>
<body>
    <div class="container">
    <h2 class="d-flex justify-content-center my-5">Install DataBase</h2>

        <form action="" method="post">
            <div class="error text-center my-5">
            <?php echo $msj;?>
            </div>   

            <div class="form-group row">
                <label class="col-2 col-form-label">Servidor</label>
                <div class="col-10">
                    <input type="text" value="<?php echo $host; ?>" name="host" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">Usuario</label>
                <div class="col-10">
                    <input type="text" value="<?php echo $user; ?>" name="user" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">ContraseÃ±a</label>
                <div class="col-10">
                    <input type="text"value="<?php echo $pass; ?>" name="pass" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">Base de Datos</label>
                <div class="col-10">
                    <input type="text" value="<?php echo $name; ?>" name="name" class="form-control">
                </div>
            </div>
            <div class="form-group text-center">
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
    
    

<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

</body>
</html>