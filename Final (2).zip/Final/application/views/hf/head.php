<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    
</head>
<body>
    <div id = "cabeza">
    </div>
    <nav class = "menu">
        <ul>
            <li><a href="<?php echo base_url('');?>">Inicio</a></li>
            <li><a href="<?php echo base_url('Noticias_c/');?>">Noticias</a></li>
            <li id='dos'><a href="<?php echo base_url('Miembros_c/');?>">Miembros</a>
                <ul id='uno'>
                    <?php
                        if(isset($_SESSION['user'])){
                            echo "<li><a href='".base_url('Miembros_c/miembros')."'>Miembros!</a></li>";
                        }else{
                            echo "<li><a href='#'>Iniciar/ Registrarse!</a></li>";
                        }
                    ?>
                    
                </ul></li>
            <li ><a href="<?php echo base_url('Galeria_c/');?>">Galería de fotos.</a></li>
            <li><a href="<?php echo base_url('Eventos_c/');?>">Eventos</a></li>
            <li><a href="<?php echo base_url('Clasificados_c/');?>">Clasificados</a></li>
            <li><a href="<?php echo base_url('Contacto_c/');?>">Contacto</a></li>
            <li><a href="<?php echo base_url('FAQ_c/');?>">Preguntas frecuentes</a></li>
            <li><a href="<?php echo base_url('Admin_c/');?>">Admin</a></li>
            <?php
                    if(isset($_SESSION['user'])){
                        echo " <li><a type = 'button' class = 'btn btn-danger' href = '".base_url('Miembros_c/logout')."' > Cerrar Sesión!</a></li>";
                    }
                ?>
        </ul>
            <br>
        </nav>
        <script>
            $(document).ready(function(){
                var altura = $('.menu').offset().top;
                $(window).on('scroll', function(){
                    if($(window).scrollTop() > altura){
                        $('.menu').addClass('menu-fixed');
                    }else{
                        $('.menu').removeClass('menu-fixed');
                    }
                });
            });
        </script>
    <style>
        *{
            padding: 0;
            margin: 0;

        }
        body {
            font-family: Verdana, Arial, Helvetica, sans-serif;
            background-image: url('./imagenes/pan.png');
            background-attachment: fixed;
            background-position: center;
            background-size: 135%;
            padding: 0;
        }
      /*GENERAL*/
      nav ul {
          margin-top: 0;
          list-style: none;
          padding: 10px;
      }
      nav li {
          line-height: 3rem;
          position: relative;
          height: 50px;
      }
      nav li ul {
          position: absolute;
      }
      nav a {
          text-decoration: none;
          color: #B06B21;
          display: block;
          padding: 0 20px;
      }
      
      a:hover {
          background: rgba( 333, 333, 333, .3);
          transition: .5s;
      }
      /*PRIMER NIVEL*/
      nav > ul {
          background: rgba(0, 0, 0, 1);
          display: table;
          width: 100%;
      }
      nav > ul > li {
          float: left;
      }
      /*SEGUNDO NIVEL*/
      nav li li {
          background: rgba(0, 0, 0, .8);
          padding: 0;
          display: none;
      }
      nav li:hover li {
          display: block;
          width: 198px;
      }
      #cabeza {
          background-image: url('./imagenes/fondo.png');
          background-attachment: fixed;
          background-size: 100%;
          width: 100%;
          height: 288px;
      }
      .menu-fixed{
        position: fixed;
        z-index: 1000;
        top: 0;
        width: 100%;
      }
      
    </style>