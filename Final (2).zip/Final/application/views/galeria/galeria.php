<style>
    #cont{
        background-color: rgba(0, 0, 0, .4);
        height: 900px;;
        width: 90%;
        margin-top: -18px;
        margin-left: 5%;
    }
</style>
<div id = "cont">
    hola
</div>
