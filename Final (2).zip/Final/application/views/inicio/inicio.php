<div id = "cont">
    <div class = "eventos">
    
    </div>
    <div class = "noticias">
    
    </div>
</div>
<style>
    #cont{
        background-color: rgba(0, 0, 0, .4);
        height: 900px;;
        width: 90%;
        margin-top: -18px;
        margin-left: 5%;
    }
    .eventos{
        float:right;
        width:25%;
        height:100%;
        background-color: rgba(333, 333, 333, .3);
    }
    .noticias{
        width:73%;
        height:100%;
        background-color: red;
        background-color: rgba(333, 333, 333, .3);
    }
</style>