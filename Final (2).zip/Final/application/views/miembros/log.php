<?php
    class login{
        public $id;
        public $cedula;
        public $user;
        public $pass;
    }