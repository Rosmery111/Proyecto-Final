<?php
    $CI =& get_instance();
    $login = new login();
    if($_POST){
        $login->id = $_POST['id'];
        $login->user = $_POST['user'];
        $login->pass = $_POST['pass'];

        $sql = $CI->db->query("select * from usuarios where correo = '{$login->user}' and contrasena = {$login->pass}")->result_array();

        if(count($sql) > 0){
            foreach($sql as $validar){
                $_SESSION['user'] = $validar['correo'];
                $_SESSION['pass'] = $validar['contrasena'];
                $login->cedula = $validar['cedula'];
                $CI->db->insert('login', $login);
                echo "<script> alert('Has iniciado Sesión!');
                window.location = '".base_url('Miembros_c/index')."';</script>";
            }
            }else{
                echo "<script> alert('Correo o contraseña no coinsiden!');
                window.location = '".base_url('Miembros_c/index')."';</script>";
        }
    }
?>