<?php   
    $CI =& get_instance();
    session_destroy();
    echo "<script>alert('Has cerrado sesión!');
    window.location = '".base_url('Miembros_c/index')."';</script>";
?>