<?php
    class registrar{
        public $cedula;
        public $nombre;
        public $apellido;
        public $telefono;
        public $correo;
        public $foto;
        public $direccion;
        public $contrasena;
    }
?>