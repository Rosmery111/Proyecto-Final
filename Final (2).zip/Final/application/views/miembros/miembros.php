<?php
    $CI =& get_instance();
    $registrar = new registrar();
    if(isset($_SESSION['user'])){
?>
    <div class = "container">
        <table class = "table">
            <thead>
                <tr>
                    <th>Foto:</th>
                    <th>Nombre:</th>
                    <th>Teléfono:</th>
                    <th>Correo:</th>
                   <?php if($_SESSION['user'] == "admin"){
                            echo "<th>Dirección!</th>";
                        }
                    ?>
                </tr>
            </thead>
        
            <tbody>
                <?php
                    $CI =& get_instance();
                    $sql = $CI->db->query("select * from usuarios where correo != 'admin'")->result_array();
                    foreach($sql as $usuarios){
                        echo "<tr>
                        <td><img src = 'http://localhost:8080/Final/{$usuarios['foto']}'></td>
                        <td>".$usuarios['nombre']."</td>
                        <td>".$usuarios['telefono']."</td>
                        <td>".$usuarios['correo']."</td>";
                        if($_SESSION['user'] == "admin"){
                            echo "<td><a type 'button' class = 'btn btn-info' href = '#'>Ver! </a></td>";
                        }
                    echo "</tr>";
                    }
                ?>
            </tbody>
        </table>
    </div> 

        <style>
        .container{
            background-color: rgba( 0, 0, 0, .4);
            height: 100%;
            color: black;
            width: 70%;
        }
        img{
            width: 50px;
            height: 50px;
        }
        a{

        }
        </style>
<?php  }else{
        if($_POST){
            $registrar->cedula = $_POST['cedula'];
            $registrar->nombre = $_POST['nombre'];
            $registrar->apellido = $_POST['apellido'];
            $registrar->telefono = $_POST['telefono'];
            $registrar->correo = $_POST['correo'];

            $nombre = $_FILES['foto']['name'];
            $nombretmp = $_FILES['foto']['tmp_name'];
            $ruta = "./Fotos/".$nombre;
            $rutta = "Fotos/".$nombre;
            move_uploaded_file($nombretmp, $ruta);
            $registrar->foto = $rutta;

            $registrar->direccion = $_POST['direccion'];
            $registrar->contrasena = $_POST['contrasena'];

            $sql = $CI->db->query("select * from usuarios where cedula = {$registrar->cedula}")->result_array();
            $query = $CI->db->query("select * from usuarios where correo = '{$registrar->correo}'")->result_array();
            if(count($query) > 0){
                echo "<script>alert(
                    'Éste Correo ya existe!'
                );
                window.location = '".base_url('Miembros_c/index')."'; </script>"; 
            }
                if(count($sql) > 0){
                    echo "<script>alert(
                        'Ésta Cédula ya existe!'
                    );  window.location = '".base_url('Miembros_c/index')."'; </script>";
                }else{
                    $CI->db->insert('usuarios', $registrar);
                }
            }
?>
<style>
    #cont{
        background-color: rgba(0, 0, 0, .4);
        height: 900px;;
        width: 90%;
        margin-top: -18px;
        margin-left: 5%;
    }
    .reg{
        float:right;
        margin-right: 150px;
        background-color: rgba( 333, 333, 333, .2);
        width: 450px;
        height: 500px;
        padding: 40px;
        font-size: 20px;
    }
    .login{
        margin-left: 150px;
        font-size: 18px;
        width: 350px;
        height: 300px;
        background-color: rgba( 333, 333, 333, .2);
        padding: 40px;
    }
</style>
<div id = "cont">
<br>
            <br>
            <br>
            <div class = 'reg'>
            
                <h2>Registrar</h2>
                <form method = 'post' enctype = "multipart/form-data">
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon' >Cédula: </span>
                        <input type='text' class = 'form-control' name = 'cedula'>
                    </div>
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon' >Nombre: </span>
                        <input type='text' class = 'form-control' name = 'nombre'>
                    </div>
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon' >Apellido: </span>
                        <input type='text' class = 'form-control' name = 'apellido'>
                    </div>
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon' >Teléfono: </span>
                        <input type='text' class = 'form-control' name = 'telefono'>
                    </div>
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon' >Correo: </span>
                        <input type='text' class = 'form-control' name = 'correo'>
                    </div>
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon' >Foto: </span>
                        <input type='file' class = 'form-control' name = 'foto'>
                    </div>
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon' >Dirección: </span>
                        <input type='text' class = 'form-control' name = 'direccion'>
                    </div>
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon' >Contraseña: </span>
                        <input type='pass' class = 'form-control' name = 'contrasena'>
                    </div>
                    
                    <div class = 'form-group input-group'>
                        <button type='submit' class = 'btn btn-primary' name = 'registrar'>Registrar!</button>
                    </div>
                </form>
            </div>
            <div class = 'login'>
                <h2>Iniciar Sesión!</h2>
                <br>
                <form method = 'post' action = 'login'>
                <input type='text' class = 'form-control hidden' name = 'id'>
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon' >Usuario: </span>
                        <input type='text' class = 'form-control' name = 'user'>
                    </div>
                    <div class = 'form-group input-group'>
                        <span class = 'input-group-addon'>Contraseña: </span>
                        <input type='text' class = 'form-control'  name = 'pass'>
                    </div>
                    <div class = 'form-group input-group'>
                        <button type='submit' class = 'btn btn-success' name = 'iniciar'>Iniciar</button>
                    </div>
                </form>
            </div>
</div>
<?php
    }
    ?>