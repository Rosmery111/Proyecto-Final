<div id = "cont">
<br>
<br>
<h1> Noticias!</h1>

    <?php
        $CI =& get_instance();
        if(isset($_SESSION['user']) == "admin"){
            echo "<a type = 'button' class = 'btn btn-success' href='".base_url('Noticias_c/agregar')."'>Agregar Nueva!</a>";
        }
    ?>
    <hr>
    <div>
        <?php
            $noticias = $CI->db->query("select * from noticias")->result_array();
            
            foreach($noticias as $noticia){
                
            }
        ?>
    </div>
</div>
<style>
    #cont{
        background-color: rgba(0, 0, 0, .4);
        height: 900px;;
        width: 90%;
        margin-top: -18px;
        margin-left: 5%;
    }
    .btn-success{
        margin: 10px;
        margin-left: 10%;
    }
    h1{
        margin-left: 40%;
        color: white;
    }
    hr{
        margin-left: 10%;
        width: 80%;
    }
    p > img{
        float: left;
    }
</style>
