<?php
    class agregar{
        public $id;
        public $titulo;
        public $resumen;
        public $foto;
        public $desarrollo;
        public $fecha;
    }
?>
