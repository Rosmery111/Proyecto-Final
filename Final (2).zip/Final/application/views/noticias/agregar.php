<?php
    $CI =& get_instance();
    $agregar = new agregar();
    if($_POST && $_FILES){
        $agregar->id = $_POST['id'];
        $agregar->titulo = $_POST['titulo'];
        $agregar->resumen = $_POST['resumen'];

        
        $nombre = $_FILES['fotos']['name'];
        $tmpNombre = $_FILES['fotos']['tmp_name'];
        $ruta = "./Fotos/".$nombre;
        $rutta = "Fotos/".$nombre;
        move_uploaded_file($tmpNombre, $ruta);
        $agregar->foto = $rutta;


        $agregar->desarrollo = $_POST['desarrollo'];
        $agregar->fecha = $_POST['fecha'];



        $CI->db->insert('noticias', $agregar);
        $agregar->id = $CI->db->insert_id();

        echo "<script>alert(
            'Oops...',
            'Something went wrong!',
            'error'
        );</script>";
    }
?>
<style>
    #cont{
        background-color: rgba(0, 0, 0, .4);
        height: 900px;;
        width: 90%;
        margin-top: -18px;
        margin-left: 5%;
    }
</style>
<div id = "cont">
    <br>
    <br>
    <h1> Noticias!</h1>
    <hr>
    <div class = "container">
        <form method= 'post' enctype = "multipart/form-data">
        <input type="text" name = "id">
        <div class = 'form-group input-group'>
            <span class = 'input-group-addon' >Título: </span>
            <input type='text' class = 'form-control' name = 'titulo'>
        </div>
        <div class = 'form-group input-group'>
            <span class = 'input-group-addon' >Resumen: </span>
            <input type='text' class = 'form-control' name = 'resumen'>
        </div>
        <div class = 'form-group input-group'>
            <span class = 'input-group-addon' >Foto: </span>
            <input type='file' class = 'form-control' name = 'fotos'>
        </div>

            <!-- Create a tag that we will use as the editable area. -->
    <!-- You can use a div tag as well. -->
    <textarea name = "desarrollo"></textarea>
 
    <!-- Include external JS libs. -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.25.0/codemirror.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.25.0/mode/xml/xml.min.js"></script>
 
    <!-- Include Editor JS files. -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.7.2/js/froala_editor.pkgd.min.js"></script>
 
    <!-- Initialize the editor. -->
    <script> $(function() { $('textarea').froalaEditor() }); </script>
    <div class = 'form-group input-group'>
                <span class = 'input-group-addon' >Fecha: </span>
                <input type='date' class = 'form-control' name = 'fecha'>
    </div>
    
    <br>
            <button type = "submit" class = "btn btn-success" name = "agregar">Agregar!</button>   
        </form>

    </div>
           
</div>