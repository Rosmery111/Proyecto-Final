<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Miembros_c extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->database();
    }

    function index(){
        $this->load->view('miembros/reg');
        $this->load->view('head');
        $this->load->view('miembros/miembros');

    }
    function login(){
        $this->load->view('miembros/log');
        $this->load->view('miembros/login');
    }
    function logout(){
        $this->load->view('miembros/logout');
    }
}