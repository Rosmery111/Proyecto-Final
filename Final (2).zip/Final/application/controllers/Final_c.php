<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Final_c extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->database();
    }

    function index(){
        $this->load->view('hf/head');
        $this->load->view('inicio/inicio');
        
        
    }
}