<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class FAQ_c extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->database();
    }

    function index(){
        $this->load->view('head');
        $this->load->view('faq/faq');
    }
}