<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Noticias_c extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->database();
    }

    function index(){
        $this->load->view('head');
        $this->load->view('noticias/noticias');
    }
    function agregar(){
        $this->load->view('noticias/ag');
        $this->load->view('head');
        $this->load->view('noticias/agregar');
    }
}